/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;

import java.util.Date;
import javax.tools.DocumentationTool.Location;

/**
 *
 * @author macstudent
 */
public class Flight {
    
    //Itinerary class was deleted
    Itinerary itinerary;
    DepartureDate departureDate;
    
    String number;
    //Itinerary Itinerary;
    String pilotName;
    
    public void getItinerary(){
        
    }
    
    //gets and setters
    public String getNumber() { return this.number; }
    public void setNumber(String name) { this.number = number; }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;

/**
 *
 * @author macstudent
 */
public class Fare extends Flight{
    int price;

    public Fare(int price) {
        this.price = price;
    }
}

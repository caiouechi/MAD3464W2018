/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;



/**
 * the place of flight
 * @author macstudent
 */
public class Itinerary{
    String startPoint;
    String endPoint;
    
    Itinerary(String startPoint, String endPoint){
        this.startPoint = startPoint;
        this.endPoint = endPoint;
    }
    
    //get and setters
    /**
     * get the startpoint, such as Brazil
     * @return 
     */
   public String getStartPoint(){
       return this.startPoint;
   } 
   
   /**
    * set the startpoint
    * @param startPoint 
    */
   public void setStartPoint(String startPoint){
       this.startPoint = startPoint;
   } 
   
   /**
    * return the end point
    * @return 
    */
     public String getEndPoint(){
       return this.endPoint;
   } 
   
     /**
      * set the end point
      * @param endPoint 
      */
   public void setEndPoint(String endPoint){
       this.endPoint = endPoint;
   }
}

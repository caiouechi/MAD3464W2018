/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;

/**
 * the fare will be charged when the user pays
 * @author macstudent
 */
public class Fare extends Flight{
    double price;
    
    /**
     * A fare belongs to a flight
     * @param price
     * @param itinerary
     * @param departureDate
     * @param number
     * @param pilotName 
     */
    public Fare(Double price, Itinerary itinerary, DepartureDate departureDate, String number, String pilotName) {
        super(itinerary, departureDate, number, pilotName);
        this.price = price;
    }
    
    /**
     * gets the price
     * @return 
     */
    public double getPrice(){
        return this.price;
    }
    
    /**
     * sets the price of the fare
     * @param price 
     */
    public void setPrice(double price){
        this.price = price;
    }
}

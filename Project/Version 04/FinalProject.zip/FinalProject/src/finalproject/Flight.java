/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.tools.DocumentationTool.Location;

/**
 * Show the passenger list of the flightrepository
 * @author macstudent
 */
public class Flight extends PassengerList {

    //Itinerary class was deleted
    Itinerary itinerary;
    DepartureDate departureDate;

    String number;
    String pilotName;

    //it will be set as false when all the seats are reserved
    boolean isAvailable = true;

    //0 = available, n > 0 = passengerId Reservation
    Map<Seat, Integer> passengerList = new HashMap<Seat, Integer>();

/**
 * Flight inherits from passengerlist
 * @param itinerary
 * @param departureDate
 * @param number
 * @param pilotName 
 */   
    Flight(Itinerary itinerary, DepartureDate departureDate, String number, String pilotName) {
        this.itinerary = itinerary;
        this.departureDate = departureDate;
        this.number = number;
        this.pilotName = pilotName;
        initializeSeats();
    }

    /**
     * Set the passenger seat according to the passenger ID
     * @param passengerID
     * @return 
     */
    //Return the PassengerSeat reserved
    @Override
    public int setPassengerSeat(Integer passengerID) {
        Integer seatReserved = 0;
        for (Map.Entry<Seat, Integer> entry : this.passengerList.entrySet()) {
            if (entry.getValue() == 0) {
                entry.setValue(passengerID);
                seatReserved = entry.getKey().Number;
                System.out.println("Seat number: " + seatReserved + " for the passengerID: " + passengerID);
                break;
            }
        }
        verifyFlighAvailable();

        return seatReserved;
    }

    //Return the PassengerSeat removed
    /**
     * Remove a seat of a certain passenger
     * @param passengerID
     * @return 
     */
    @Override
    public int removePassengerSeat(Integer passengerID) {
        Integer seatReserved = 0;
        for (Map.Entry<Seat, Integer> entry : this.passengerList.entrySet()) {
            if (entry.getValue() == passengerID) {
                Seat objSeat = new Seat();
                objSeat.Number = 0;
                entry.setValue(objSeat.Number);
                seatReserved = entry.getKey().Number;
                System.out.println("Seat removed: " + seatReserved);
            }
        }
        verifyFlighAvailable();

        return seatReserved;
    }

    /**
     * Show if the seats is reserved or not
     */
    public void showSeatsStatus() {

        System.out.println("Flight number: " + this.number);
        for (Map.Entry<Seat, Integer> entry : this.passengerList.entrySet()) {
            System.out.println("Seat: " + entry.getKey().Number + " Reserved for the passenger [" + entry.getValue() + "]");
        }
        
        System.out.println("");
    }

    public void verifyFlighAvailable() {
        this.isAvailable = false;
        for (Integer value : this.passengerList.values()) {
            if (value == 0) {
                this.isAvailable = true;
            }
        }
    }

    /**
     * set all the seats to not reserved
     */
    private void initializeSeats() {
        int count;
        for (count = 1; count < 11; count++) {
            Seat objSeat = new Seat();
            objSeat.Number = count;
            passengerList.put(objSeat, 0);
        }
    }

    /**
     * Get the itinerary
     */
    public void getItinerary() {
        System.out.println("Itinerary info: ");
        System.out.println("Start point: " + itinerary.startPoint);
        System.out.println("End point: " + itinerary.endPoint);
    }

    //gets and setters
    /**
     * Get the number flight
     * @return 
     */
    public String getNumber() {
        return this.number;
    }

    /**
     * Set the number flight
     * @param name 
     */
    public void setNumber(String name) {
        this.number = number;
    }

    /**
     * @return Return the pilotname
     */
    public String getPilotName() {
        return this.pilotName;
    }

    /**
     * Set the pilot name
     * @param pilotName 
     */
    public void setPilotName(String pilotName) {
        this.pilotName = pilotName;
    }

}

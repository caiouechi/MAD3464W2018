/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;

/**
 * seats will be the key of the dictionary in flight class
 * @author macstudent
 */
public class Seat {
   int Number;
}

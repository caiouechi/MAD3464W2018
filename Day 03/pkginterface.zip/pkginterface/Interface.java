/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkginterface;

/**
 *
 * @author macstudent
 * diamond problem -> a, b and c inherits
 * diamon explanation https://dzone.com/articles/dealing-with-diamond-problem-in-java
 */
public class Interface {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
//Addition op1 = new Addition();
//op1.display();
        
//Counting cn1 = new Counting();
//cn1.display();
    

//A a1 = new A();
//a1.display();
//a1.calcMultiplication();

//B b1 = new B();
//b1.display();
//b1.calcMultiplication();
//b1.calcDivision();


//C c1 = new C();

}
}

interface Arithmetic{
    int n1 = 10;
    int n2 = 10;
    void display();
}

class Addition implements Arithmetic{

    @Override
    public void display() {
        System.out.println("Inside Addition class");
    } 
}
class Counting extends Addition{
    
}

interface multiplication extends Arithmetic {
    void calcMultiplication();
}

class A implements multiplication{
    
    @Override
    public void display(){
        System.out.println("n1 = " + n1 + " n2= " + n2);
    }
    
    @Override
    public void calcMultiplication(){
        System.out.println("multiplication: " + (n1*n2));
    }
}

interface division extends Arithmetic{
    void calcDivision();
}
class B implements division, multiplication{

    @Override
    public void calcMultiplication() {
        System.out.println("aaaa");
    }

    @Override
    public void display() {
        System.out.println("inside class B");
        System.out.println("n1 = " + n1 + " n2 = " + n2);
    }

    @Override
    public void calcDivision() {
        System.out.println("asdfasdfsafsad");
    }
    
    
}

class C extends B {
    int c1 = 20;
}
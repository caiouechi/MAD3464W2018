/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

class testException extends Exception{
 public testException(String message){
super(message);
}
}

/**
 *throws, throw, try, catch, finally    
    * @author macstudent
    */
    public class CustomizeException {

       public static void main(String args[]) throws Exception{
           int n1 = 10;

           try{
               if(n1 == 10){
                   throw new testException("tTest unsucesfsul");
               }

           } catch(testException e){

                       }
       }
    }

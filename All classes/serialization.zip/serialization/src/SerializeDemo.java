import java.io.*;

public class SerializeDemo
{
   public static void main(String [] args)
   {
      Employee e = new Employee();
      e.name = "Ashley";
      e.address = "Vancouver";
      e.SSN = 4444444;
      e.number = 101;
      
      try
      {
         FileOutputStream fileOut = new FileOutputStream("employee.txt");
         ObjectOutputStream out = new ObjectOutputStream(fileOut);
         
         out.writeObject(e);
         
         out.close();
         fileOut.close();
         
         System.out.printf("Serialized data is saved as employee.txt");
      }catch(IOException i){
          i.printStackTrace();
      }
   }
}
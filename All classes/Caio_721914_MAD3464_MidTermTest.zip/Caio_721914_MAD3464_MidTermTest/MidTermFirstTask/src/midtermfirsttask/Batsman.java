/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package midtermfirsttask;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class Batsman extends Player{
 //Data Members: noBowlsPlayed, 
 //runsTaken(array of 6 elements e.g. 0t element stores no. of 1s taken, 3rd element stores no of 4 staken by the player))
 //strikeRate, totalRuns, batingPoints   
    
    float noBowslPlayed;
    int[] runsTaken;
    float strikeRate;
    float totalRuns;
    float baitingPoints;
    
    //Call the readData() method of the base class and input only the first two data members of this class
    public void readData(){
    Scanner input = new Scanner(System.in);
    
    System.out.println("Type the noBowslPlayed");
    this.noBowslPlayed = input.nextInt();
    
    System.out.println("Type the no. of 1s taken");
    int firstTaken = input.nextInt();
    
    System.out.println("Type the no. of 2nd taken");
    int secondTaken = input.nextInt();
    
    System.out.println("Type the no. of 3rd taken");
    int thirdTaken = input.nextInt();
    
    System.out.println("Type the no. of 4th taken");
    int fourthTaken = input.nextInt();
    
    System.out.println("Type the no. of 5th taken");
    int fifithTaken = input.nextInt();
    
    System.out.println("Type the no. of 6th taken");
    int sixthTaken = input.nextInt();
    
    this.runsTaken = new int[] {firstTaken, secondTaken, thirdTaken, fourthTaken, fifithTaken, sixthTaken};
    
    super.readData();
    }
    
    //Display the player type as “Batsman”, call dispData() method of the base class and display all data members of this class
    public void dispData(){
    System.out.println("Displaying all Batsman data members:");
    System.out.println("  noBowslPlayed: " + this.noBowslPlayed);
    
    String allRuns = "";
    for(int run: this.runsTaken){
        allRuns = allRuns + run + ";";
    }
    System.out.println("  runsTaken: " + allRuns);
    System.out.println("  strikeRate: " + this.strikeRate);
    System.out.println("  totalRuns: " + this.totalRuns);
    System.out.println("  baitingPoints: " + this.baitingPoints);
    super.dispData();
    }
    
    //Set totalRuns = (total runs scored by the player) and strikeRate = (totalRuns/noBowlsPlayed)
    public void calAvg(){
        for(float run: runsTaken){
            this.totalRuns = this.totalRuns + run;
        }
        
        this.strikeRate = (this.totalRuns/this.noBowslPlayed);
    }
    
    //Calculates the points of any batsman according to following rules:
    //i. 5 points for each six
    //ii. 3 points for each four
    public void calPoints(){
       float sixPoints = 0;
       float fourPoints = 0;
       
       sixPoints = this.runsTaken[5] * 5;
       fourPoints = this.runsTaken[3] * 3;
        
       this.baitingPoints = sixPoints + fourPoints;
    }
    }

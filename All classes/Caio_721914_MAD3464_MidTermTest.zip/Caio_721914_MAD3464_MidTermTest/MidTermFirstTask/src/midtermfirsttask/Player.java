/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package midtermfirsttask;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class Player {
    String PlayerID;
    String PlayerName;
    
    //void readData() : Input all data members in this class
    public void readData(){
    Scanner input = new Scanner(System.in);
    
    System.out.println("Type the PlayerID");
    this.PlayerID = input.nextLine();
    
    System.out.println("Type the PlayerName");
    this.PlayerName = input.nextLine();
    }
    
    //void dispData() : Display all data members in this class
    public void dispData(){
        System.out.println("    Displaying all Player data members:");
        System.out.println("      PlayerID: " + this.PlayerID);
        System.out.println("      PlayerName: " + this.PlayerName);
    }
}

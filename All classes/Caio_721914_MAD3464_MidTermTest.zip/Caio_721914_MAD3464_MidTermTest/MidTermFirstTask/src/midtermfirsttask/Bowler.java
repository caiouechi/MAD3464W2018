/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package midtermfirsttask;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class Bowler extends Player{
    //Data Members: noOversThrown, noRunsGiven, noWicketsTaken, runsPerOver, runsPerWicket, bowlingPoints
    float noOversThrown;
    float noRunsGiven;
    float noWicketsTaken;
    float runsPerOver;
    float runsPerWicket;
    float bowlingPoints;
 
    //Call the readData() method of the base class and input only the first three data members of this class
    public void readData(){
    Scanner input = new Scanner(System.in);
    
    System.out.println("Type the noOversThrown");
    this.noOversThrown = input.nextInt();
    
    System.out.println("Type the noRunsGiven");
    this.noRunsGiven = input.nextInt();
    
    System.out.println("Type the noWicketsTaken");
    this.noWicketsTaken = input.nextInt();
    
    super.readData();
    }
 
    //Display the player type as “Bowler”, call dispData() method of the base class and display all data members of this class
    public void dispData(){
        System.out.println("Displaying all Bowler data members:");
        System.out.println("  noOversThrown: " + this.noOversThrown);
        System.out.println("  noRunsGiven: " + this.noRunsGiven);
        System.out.println("  noWicketsTaken: " + this.noWicketsTaken);
        System.out.println("  runsPerOver: " + this.runsPerOver);
        System.out.println("  runsPerWicket: " + this.runsPerWicket);
        System.out.println("  bowlingPoints: " + this.bowlingPoints);
        super.dispData();
    }
    
    //Set runsPerOver = (noRunsGiven/noOversThrown) runsPerWicket = (noRunsGiven/noWicketsTaken)
    public void calAvg(){
        this.runsPerOver = (this.noRunsGiven/this.noOversThrown);
        this.runsPerWicket = (this.noRunsGiven/this.noWicketsTaken);
    }
    
    //Calculates the points of bowler according to following rules: 
    //i. 5 points for each wicket
    //ii. Average runPerOver 1-3 then 10 points 
    //>3 then 5 points
    public void  calPoints(){
        float amountPoint = 0;
        amountPoint = (this.noWicketsTaken * 5);
        
        float extraPoints = 0;
        if (this.runsPerOver >= 1 && this.runsPerOver <= 3){
            extraPoints = 10;
        }else if (this.runsPerOver > 3){
            extraPoints = 5;
        }
            
        amountPoint = amountPoint + extraPoints;
        this.bowlingPoints = amountPoint;
    }
    
}

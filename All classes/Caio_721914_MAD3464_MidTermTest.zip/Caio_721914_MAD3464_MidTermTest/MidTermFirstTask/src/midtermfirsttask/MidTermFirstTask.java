/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package midtermfirsttask;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class MidTermFirstTask {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
  Scanner input = new Scanner(System.in);
        
//        Player player = new Player();
//        player.readData();
//        player.dispData();

        ArrayList<Player> playerList = new ArrayList<Player>();

        int numberPlayer = 1;
        while (numberPlayer < 5){
        playerList.add(PlayerConfigs(numberPlayer));     
        numberPlayer++;
        }
        
        System.out.println("All 4 players were created. Do You want to see the details? Press 1 to yes or 2 to no.");
        int userChoice = input.nextInt();

        if (userChoice == 1){
            for(Player player: playerList){
            player.dispData();
            }
        }
        
        
        System.out.println("Thank you for using this software");
        
    }
    
    
static Player PlayerConfigs(int numberPlayer){
      Scanner input = new Scanner(System.in);
System.out.println("Player number: " + numberPlayer);      
System.out.println("Type 1 for Bowler and 2 for Batsman");
int userChoice = input.nextInt();

if (userChoice == 1){
    Bowler bowler = new Bowler();
    bowler.readData();
    bowler.calAvg();
    bowler.calPoints();
    bowler.dispData();
    System.out.println();
    return bowler;
}else{
    Batsman batsman = new Batsman();
    batsman.readData();
    batsman.calAvg();
    batsman.calPoints();
    batsman.dispData();
    System.out.println();
    return batsman;
}

}

}

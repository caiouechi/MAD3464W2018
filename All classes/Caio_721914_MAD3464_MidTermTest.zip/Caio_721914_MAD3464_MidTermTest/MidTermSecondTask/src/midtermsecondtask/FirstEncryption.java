/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package midtermsecondtask;

/**
 *
 * @author macstudent
 */
public class FirstEncryption {
    //Add 1 to the even positioned character and 2 to the odd positioned character
    //E.g. for input “ZANIL” output is “BBPJN”. 
    //12345
    //ZANIL
    
    //21212 (Adding letters)
    //BBPJN
    

    public static String Convert(String wordToConvert){
        
        String alphabetic = "ABCDEFGHIJKLMNOPQRSTUVWXYZABC";
        String wordConverted = "";
           
        int i;
        //each letter
        for(i=0; i<5; i++){
        boolean isEven = false;
        char letterToConvert = wordToConvert.charAt(i);
        char letterConverted = '.';
            
        int letterIndex = alphabetic.indexOf(letterToConvert);
        int letterIndexConverted = 0;
                
        if(i%2 == 0){
            isEven = true;
        }
        
        //even + 1
        //odd +2
        if(isEven == true){
          letterIndexConverted = letterIndex + 2;
        }else{
          letterIndexConverted = letterIndex + 1;
        }
            
        letterConverted = alphabetic.charAt(letterIndexConverted);
        
        wordConverted = wordConverted + letterConverted;
        }
        
    return wordConverted;    
    }
    
    
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package midtermsecondtask;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class MidTermSecondTask {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
     Scanner input = new Scanner(System.in);
        String userInput = "";
                
     System.out.println("Type a string of length 5 characters");
        userInput = input.nextLine().toUpperCase();
        
       if (!UserInsert(userInput)){
           return;
       };
        
        String firstEncryption = FirstEncryption.Convert(userInput);
        System.out.println("The word to encrypt was: " + userInput);
        System.out.println("Encryption 1: " + firstEncryption);
        
        String secondEncryption = SecondEncryption.Convert(userInput);
        System.out.println("Encryption 2: " + secondEncryption);
        
        String thirdEncryption = ThirdEncryption.Convert(userInput);
        System.out.println("Encryption 3: " + thirdEncryption);
        
        
        System.out.println("Combination of all outputs: " + firstEncryption + secondEncryption + thirdEncryption);
    }
    
    public static boolean UserInsert(String userInput){
       
        
        //Checking if there is a number
        int i;
        boolean thereAreNumbers = false;
         
        for(i=0; i< userInput.length(); i++){
        char letter = userInput.charAt(i);
        try{
            String newString = (""+letter);
            int tryInt = Integer.parseInt(newString);
            thereAreNumbers = true;
        }catch(Exception e){
        }
        }
        
        if(thereAreNumbers == true || userInput.length() != 5){
            System.out.println("You did not insert a String of 5 characters");
            return false;
        }
        return true;
}
}

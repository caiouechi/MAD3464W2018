/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package midtermsecondtask;

/**
 *
 * @author macstudent
 */
public class ThirdEncryption {
    public static String Convert(String wordToConvert){
        String reverseWord = "";
        
        String evenLettersToTheFinal = "";
        String keepOddLetters = "";
        String wordConverted = "";
           
        int i;
        //each letter
        for(i=4; i>=0; i--){
        
        char letterToConvert = wordToConvert.charAt(i);
            reverseWord = reverseWord + letterToConvert;
        }
        
        for(i=0; i<5; i++){
        
        char letterWord = wordToConvert.charAt(i);
        char letterReverseWord = reverseWord.charAt(i);
            wordConverted = wordConverted + letterWord + letterReverseWord;
        }
        
        
    return wordConverted;    
    }
}

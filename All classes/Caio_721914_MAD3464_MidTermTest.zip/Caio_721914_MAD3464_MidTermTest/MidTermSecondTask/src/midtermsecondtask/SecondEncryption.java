/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package midtermsecondtask;

/**
 *
 * @author macstudent
 */
public class SecondEncryption {
    
    public static String Convert(String wordToConvert){
        
        String evenLettersToTheFinal = "";
        String keepOddLetters = "";
       
        String wordConverted = "";
           
        int i;
        //each letter
        for(i=0; i<5; i++){
        boolean isEven = false;
        char letterToConvert = wordToConvert.charAt(i);
        char letterConverted = '.';
            
      
                
        if(i%2 == 0){
            isEven = true;
        }
        
        //even + 1
        //odd +2
        if(isEven == true){
        evenLettersToTheFinal = evenLettersToTheFinal + letterToConvert;
        }else{
            keepOddLetters = keepOddLetters + letterToConvert;
        }
        }
        
        wordConverted = keepOddLetters + evenLettersToTheFinal;
    return wordConverted;    
    }
    
}


import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
 * Author: Jigisha Patel
 * Purpose: Academic
 * 
 */

/**
 *
 * @author jkp
 */
public class RegEx {
    public static void main(String args[]){
        Pattern pat;
        Matcher mat;
        boolean found;

        pat=Pattern.compile("Java");
        mat=pat.matcher("Java");
        
       // mat=pat.matcher("Java 2"); 

        found=mat.matches(); //check for a match

        System.out.println("Testing Java against Java");

        if(found)
        {
            System.out.println("Matches");
        }
        else
        {
            System.out.println("No match");
        }

        pat = Pattern.compile("Java");
        mat=pat.matcher("Java2");

        System.out.println("Looking for Java in Java2.");

        if (mat.find())
        {
            System.out.println("subsequent found");
        }
        else
        {
            System.out.println("No matches");
        }
        
        pat = Pattern.compile("Test");
        mat=pat.matcher("Test 1 2 3 Test");

        System.out.println("Looking for Java in Java 2.");

        while(mat.find())
        {
            System.out.println("Test found at index " + mat.start());
        }
        
        pat=Pattern.compile("W+");
        mat=pat.matcher("W WW WWW WW WP");
        
//        pat=Pattern.compile("e.+?d");
//        mat=pat.matcher("extend cup end table" );
//        
//        pat=Pattern.compile("[a-z]+");
//        mat=pat.matcher("EXTEND cup end table" );

        while(mat.find())
        {
            System.out.println("Match :" + mat.group());
        }
        
    }
}

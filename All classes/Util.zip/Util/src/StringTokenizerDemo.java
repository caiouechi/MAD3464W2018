/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jkp
 */

import java.util.*;

public class StringTokenizerDemo {
   public static void main(String[] args) {
      // creating string tokenizer
      StringTokenizer st = new StringTokenizer("This is a test String");
      
      // counting tokens
      System.out.println("Total tokens : " + st.countTokens());       
      
      // checking elements
      while (st.hasMoreElements()){
          System.out.println("(nextelement) Next element : " + st.nextElement());}
      
      // checking tokens
      while (st.hasMoreTokens()){
         System.out.println("(hasmoretokens) Next token : " + st.nextToken());    }
         
      StringTokenizer st1 = new StringTokenizer("Come to learn");
      
      // moving to next element
      st1.nextElement();
      
      // checking next to next element
      System.out.println("(next element) Next element is : " + st1.nextElement());
      
      StringTokenizer st2 = new StringTokenizer("Come/to/learn");
      
      // checking next token
      System.out.println("(delimiter) Next token is : " + st2.nextToken("/"));
   }
}   


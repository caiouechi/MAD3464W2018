/*
 * Author: Jigisha Patel
 * Purpose: Academic
 * 
 */
package day3exceptions;

/**
 *
 * @author jkp
 */
class testException extends Exception {

    public testException(String message) {
        super(message);
    }
}

public class CustomizeException {

    public static void main(String args[]) throws Exception {
        int n1 = 10;

        try {
            if (n1 == 10) {
                throw new testException("Test unsuccessful");
            }
        } catch (testException e) {
            System.out.println("customized exception");
            System.out.println(e.getMessage());
            System.out.println(e.getStackTrace());
        }
    }
}

/*
 * Author: Jigisha Patel
 * Purpose: Academic
 * 
 */
package Day4Abstract;

/**
 *
 * @author jkp
 */
public class Shape {
    public static void main(String args[]){
       // MyShape obj1 = new MyShape();
       
       Circle c1 = new Circle();
       c1.draw();
       c1.display("Its a Circle !!");
        
    }
}

abstract class MyShape{
    int x;
    int y;
    
    abstract void draw();
    
    void display(String msg){
        System.out.println(msg);
    }
    
}

class Circle extends MyShape{

    @Override
    void draw() {
        System.out.println("Drawing circle");
        super.x = 20;
        super.y = 30;
        System.out.println(" x = " + super.x + " y = "+super.y);
    }
}

abstract class Rectangle extends MyShape{
    int h;
    
    abstract void draw();
}
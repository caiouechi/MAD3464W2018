/*
 * Author: Jigisha Patel
 * Purpose: Academic
 * 
 */
package arraylisttest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.*;

/**
 *
 * @author jkp
 */
public class ArrayListTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Books book1 = new Books(1,"The Sky",8);
        Books book2 = new Books(2,"Necklace",3);
        Books book3 = new Books(3,"Milk",2);
        Books book4 = new Books(4,"Journey",3);
        Books book5 = new Books(5,"Wonderer",4);
        
        ArrayList<Books> library = new ArrayList<Books>();
        library.add(book1);
        library.add(book2);
        library.add(book3);
        library.add(book4);
        library.add(book5);
        
        System.out.println("No. of books: " + library.size());
        
        for (Books bk: library){
           // bk.displayInfo();
        }
        
        library.add(2,new Books(10,"Pecific",9));
        
        library.forEach( bk -> {
            //bk.displayInfo();
        });
        
        Collections.sort(library,new bookRatingComparator());
       
        library.forEach( bk -> {
            bk.displayInfo();
        });
        
        Collections.sort(library, new bookTitleComparator());
        for (Books bk: library){
            //bk.displayInfo();
        }
        
        
        
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class Task {

    public static void showCommands(AirlineReservationSystem obj){
               System.out.println("Please type 1 for “smoking”");
        System.out.println("Please type 2 for 'non-smoking'");
        System.out.println("Please type 3 to check the available seats");
        System.out.println("Please type 4 to assign a seat");
        
               Scanner input = new Scanner(System.in);
        
      
        
        switch (input.nextLine()) {
            case "3":
                obj.returnAvailableSeats();
                
                break;
            case "4":
                System.out.println("Please type the seat number to assign");
                Scanner seatNumber = new Scanner(System.in);
                obj.assignSeatPosition(seatNumber.nextInt());
                break;  
            default:
                break;
        }
                
        restartProject(obj);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
          AirlineReservationSystem newObj = new AirlineReservationSystem();
          
        showCommands(newObj);
        
 
                    
             
    }
    
    public static void restartProject(AirlineReservationSystem obj){
        System.out.println("Press 'r' to restart the menu");
        Scanner nextInput = new Scanner(System.in);
        String userInput = nextInput.nextLine();
        
        
        if(userInput.equals("r")){
               showCommands(obj);
                      //System.out.println("teste");
        }else{
            System.out.println("Menu ended");
        }
    }
    
}

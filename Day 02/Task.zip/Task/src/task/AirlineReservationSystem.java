/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task;

/**
 *
 * @author macstudent
 */
public class AirlineReservationSystem {
    
     static int[] seatsAirplane;
     
     // 0 to available, and 1 seat unavailable
     public AirlineReservationSystem(){
         seatsAirplane = new int[10];
         //set all seats to 0
         int i;
         for(i=0; i<10;i++){
         seatsAirplane[i] = 0;    
         }
         
         
     }
           
     boolean assignSeatPosition(int numberSeat){
         if(seatsAirplane[numberSeat] == 0){
             
             seatsAirplane[numberSeat] = 1;
               System.out.println("Seat assigned");
                     return true;
         }else{
               System.out.println("Seat already assigned to another person");
                     return false;
         }
        }
     
     int[] returnAvailableSeats(){
         int[] availableSeats = new int[10];
       
         System.out.println("Seats available:");
         
                 //set all seats to 0
         int i;
         for(i=0; i<10;i++){
         if(seatsAirplane[i] == 0){
           System.out.println("#" + i);  
         }
         }
         
          return availableSeats;
        }
     
     
}

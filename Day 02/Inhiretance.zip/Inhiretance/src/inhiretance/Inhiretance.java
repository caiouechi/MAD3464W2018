/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inhiretance;

//Read about Diamont Problem 
//method overloading vs method overriding (the type, name) vs(perform inhiretance)

public class Inhiretance {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Person one = new Person();
        //one.readData();
        one.displayData();
        
        
        Person sreejith = new Person("ola", "ole", 10);
        sreejith.displayData();
        
        Employee e1 = new Employee("asdf","asdfads",2,5);
        
        
        
        
        
        
    }
    
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inhiretance;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class Person {
    String firstName;
    String lastName;
    int age;
    
    //constructor
    Person(){
        this.firstName = "Unknown";
        this.lastName = "Unknown";
        this.age = 1;
    }
    
    Person(Person object){
               this.firstName = object.firstName;
        this.lastName = object.lastName;
        this.age = object.age;
    }
    
    //parameterized constructor
    Person(String param1, String param2, int paramAge){
          this.firstName = param1;
        this.lastName = param2;
        this.age = paramAge;
    }
    
    void readData(){
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter first name: " );
        this.firstName = input.nextLine();
        
        System.out.println("Enter last name: ");
        this.lastName = input.nextLine();
        
        System.out.println("Enter age: ");
        this.age = input.nextInt();
    }
    
    
    void displayData(){
        System.out.println("First name: " + this.firstName);
        System.out.println("Last Name: " + this.lastName);
        System.out.println("Age: "+ this.age);
    }
    
}
